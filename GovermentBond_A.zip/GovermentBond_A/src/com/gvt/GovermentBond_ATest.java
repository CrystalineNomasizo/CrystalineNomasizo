package com.gvt;

import org.junit.Test;
import java.time.LocalDate;

import static org.junit.Assert.*;

public class GovermentBond_ATest {
    @Test
    public void testR186_bondCalculation() {
        // Creating bond details for R186 bond with specific parameters
        BondDetails R186_bond = new BondDetails(
                LocalDate.of(2026, 12, 21), // maturityDate
                10.5, // couponRate
                100.00, // R (face value)
                LocalDate.of(2017, 6, 21), // NCD (Next Coupon Date)
                LocalDate.of(2016, 12, 21), // LCD (Last Coupon Date)
                LocalDate.of(2017, 6, 11), // booksCloseDate1
                LocalDate.of(2017, 12, 11), // booksCloseDate2
                LocalDate.of(2017, 2, 7), // settlementDate
                8.75 // yield
        );

        // Calculating accrued interest for the R186 bond
        double accruedInterest = GovermentBond_A.calculateAccruedInterest(R186_bond);
        // Printing the calculated accrued interest
        System.out.println(round(accruedInterest, 5));
        // Asserting the calculated accrued interest matches the expected value
        assertEquals(1.38082, round(accruedInterest, 5), 0.00001);

        // Calculating the All-In Price (AIP) for the R186 bond
        double aip = GovermentBond_A.calculateAIP(R186_bond);
        // Printing the calculated AIP
        System.out.println(round(aip, 5));
        // Asserting the calculated AIP matches the expected value
        assertEquals(112.77263, round(aip, 5), 0.00001);

        // Calculating the clean price for the R186 bond
        double cleanPrice = GovermentBond_A.calculateCleanPrice(aip, accruedInterest);
        // Printing the calculated clean price
        System.out.println(round(cleanPrice, 5));
        // Asserting the calculated clean price matches the expected value
        assertEquals(111.39181, round(cleanPrice, 5), 0.00001);
    }

    @Test
    public void testR2032_bondCalculationB() {
        // Creating bond details for R2032 bond with specific parameters
        BondDetails R2032_bond = new BondDetails(
                LocalDate.of(2032, 3, 31), // maturityDate
                8.25, // couponRate
                100.00, // R (face value)
                LocalDate.of(2024, 9, 30), // NCD (Next Coupon Date)
                LocalDate.of(2024, 3, 31), // LCD (Last Coupon Date)
                LocalDate.of(2024, 3, 21), // booksCloseDate1
                LocalDate.of(2024, 9, 20), // booksCloseDate2
                LocalDate.of(2024, 5, 16), // settlementDate
                9.5 // yield
        );

        // Calculating accrued interest for the R2032 bond
        double accruedInterest = GovermentBond_A.calculateAccruedInterest(R2032_bond);
        // Printing the calculated accrued interest
        System.out.println(round(accruedInterest, 5));
        // Asserting the calculated accrued interest matches the expected value
        assertEquals(1.03973, round(accruedInterest, 5), 0.00001);

        // Calculating the All-In Price (AIP) for the R2032 bond
        double aip = GovermentBond_A.calculateAIP(R2032_bond);
        // Printing the calculated AIP
        System.out.println(round(aip, 5));
        // Asserting the calculated AIP matches the expected value
        assertEquals(94.19665, round(aip, 5), 0.00001);

        // Calculating the clean price for the R2032 bond
        double cleanPrice = GovermentBond_A.calculateCleanPrice(aip, accruedInterest);
        // Printing the calculated clean price
        System.out.println(round(cleanPrice, 5));
        // Asserting the calculated clean price matches the expected value
        assertEquals(93.15693, round(cleanPrice, 5), 0.00001);
    }

    // Utility method for rounding a double value to a specified number of decimal places
    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();
        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }
}
